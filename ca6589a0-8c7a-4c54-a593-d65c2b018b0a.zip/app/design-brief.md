# SlideStudio design brief

- Design read: Independent creators, founders and teams who need presentations that look considered, confident and easy to edit.
- Concept spine: The slide atelier. Each scroll reveals another layer of a well-composed deck, from blank canvas to polished presentation.
- Delivery tier: cinema, with a restrained continuous scroll-scrub hero, rich editorial typography and tactile product previews.
- Animation mode: animated-website
- Journey shape: single-shot. One continuous move around a sculptural stack of presentation panels keeps the story coherent and lightweight.
- Journey: 1) The canvas: an ivory slide plane emerges from cobalt darkness. 2) The system: a second panel and grid details appear. 3) The story: charts and layouts unfold. 4) The finished deck: the stack resolves into a confident presentation kit.
- World grammar: deep ink-blue studio, ivory paper surfaces, cobalt and tomato-red accents, soft directional studio light, crisp editorial geometry, fixed perspective and center-safe subject.
- Mobile framing: no mobile clip is shipped until a separate lightweight center-safe encode is available; hero poster and text remain responsive.
- Delivery budget: desktop clip target under 8 MiB; mobile uses the responsive static poster fallback.
- Locked palette: ink #101A2B, ivory #F7F5EF, cobalt #315BDB, tomato #E34B3F. This balances paper-like slide surfaces with a confident blue and a single red accent.
- Locked type: Cabinet Grotesk for display and Inter Tight for interface/body; sans-serif throughout for clarity.
- Section plan: hero journey; asymmetric featured templates; horizontal service story; split custom-order brief; support/chat area; FAQ and footer.
- Asset plan: original procedural motion plate and exact first-frame poster, custom SVG brand mark/favicon/OG artwork, four presentation-preview artworks, lightweight iconography.
- CTA inventory: Browse templates, Start a custom deck, Open my account, Chat with us, Manage store.
- Backend: Cloudflare D1 for accounts/catalog/orders/messages, R2 for private PPT and attachment storage, Razorpay order creation + signature/webhook verification.
- Security: hashed passwords, hashed session tokens, role checks on admin operations, validated uploads, private R2 objects, time-limited one-use download grants, parameterized D1 queries.
- Scope note: the chat is a customer support and PPT brief inbox, not a generative AI assistant. External payment/email secrets are configured in website settings, never embedded in browser code.
