CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, slug TEXT NOT NULL UNIQUE, title TEXT NOT NULL, subtitle TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT 'Business', price_paise INTEGER NOT NULL,
 compare_price_paise INTEGER, cover_key TEXT, file_key TEXT, file_name TEXT, active INTEGER NOT NULL DEFAULT 1,
 featured INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), product_id TEXT REFERENCES products(id),
 kind TEXT NOT NULL DEFAULT 'template', status TEXT NOT NULL DEFAULT 'pending', amount_paise INTEGER NOT NULL,
 currency TEXT NOT NULL DEFAULT 'INR', razorpay_order_id TEXT, razorpay_payment_id TEXT,
 customer_name TEXT, customer_email TEXT, brief TEXT, due_date TEXT, admin_note TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS download_tokens (
 token_hash TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
 product_id TEXT NOT NULL REFERENCES products(id), expires_at TEXT NOT NULL, used_at TEXT
);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id), order_id TEXT REFERENCES orders(id),
 sender_role TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', attachment_key TEXT, attachment_name TEXT,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
INSERT OR IGNORE INTO products(id,slug,title,subtitle,description,category,price_paise,compare_price_paise,cover_key,active,featured) VALUES
('ss-strategy-01','strategy-starter','The Strategy Starter','A clear story for big ideas','A structured, editable presentation system for strategy reviews, proposals and team alignment. Includes a title system, section dividers, charts and closing slides.','Business',129900,189900,'/assets/templates/preview-1.jpg',1,1),
('ss-pitch-02','founder-pitch','Founder Pitch Deck','Tell the story investors remember','A polished pitch narrative framework for problem, solution, market, traction, business model and ask.','Pitch Deck',159900,219900,'/assets/templates/preview-2.jpg',1,1),
('ss-portfolio-03','creative-portfolio','The Creative Portfolio','Make your work the headline','A flexible portfolio deck for independent creatives, studios and teams, with case study and project reveal layouts.','Portfolio',99900,NULL,'/assets/templates/preview-3.jpg',1,0),
('ss-data-04','data-story','Data Storytelling Kit','Turn numbers into a narrative','A clean set of chart, KPI, report and insight layouts designed to make complex information easier to scan.','Reports',119900,NULL,'/assets/templates/preview-4.jpg',1,0);
