import { createFileRoute } from '@tanstack/react-router'
import { bindings } from '@/lib/bindings.server'
const sha=async(v:string)=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v)))].map(x=>x.toString(16).padStart(2,'0')).join('')
export const Route=createFileRoute('/api/me')({server:{handlers:{GET:async({request})=>{const raw=request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('ss_session='))?.slice(11),db=bindings().DB;if(!raw||!db)return Response.json({user:null});const user=await db.prepare("SELECT u.id,u.name,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>datetime('now')").bind(await sha(decodeURIComponent(raw))).first();return Response.json({user})}}}})
