import { createFileRoute } from '@tanstack/react-router'
import { bindings } from '@/lib/bindings.server'
export const Route = createFileRoute('/api/health')({ server: { handlers: { GET: async () => Response.json({ok:true,database:!!bindings().DB,privateStorage:!!bindings().STORAGE}) } } })
